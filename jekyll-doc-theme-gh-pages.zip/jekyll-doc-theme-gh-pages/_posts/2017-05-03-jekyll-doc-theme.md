---
layout: post
title:  "Jekyll Doc Theme is published!"
author: aksakalli
---
A new custom Jekyll theme for documentation and blogging is out. It is ideal for Open Source Software projects to publish under [GitHub Pages](https://pages.github.com).

Your contribution is welcome!
